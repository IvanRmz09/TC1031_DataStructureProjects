#pragma once
#include <string>
using namespace std;


struct Ip {
	string code;
	Ip();
	Ip(string);
	bool operator==(Ip ip2) {
		if (code == ip2.code) {
			return true;
		}
		else {
			return false;
		}
	}

	bool operator!=(Ip ip2)
	{
		if (code != ip2.code) {
			return true;
		}
		else {
			return false;
		}
	}

	bool operator>=(Ip ip2)
	{
		if (code == ip2.code) {
			return true;
		}
		else
		{
			if (code > ip2.code) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	bool operator<=(Ip ip2)
	{
		if (code == ip2.code) {
			return true;
		}			
		else
		{
			if (code < ip2.code) {
				return true;
			}
				
			else {
				return false;
			}		
		}
	}

	bool operator>(Ip ip2)
	{
		if (code > ip2.code) {
			return true;
		}
		else {
			return false;
		}			
	}

	bool operator<(Ip ip2)
	{
		if (code < ip2.code) {
			return true;
		}
		else {
			return false;
		}
	}
};


Ip::Ip() {
	this->code = "";
}

Ip::Ip(string code) {
	this->code = code;
}
