#pragma once
#include <string>
using namespace std;


struct IpCant {
	string code;
	int cantidad;
	IpCant();
	IpCant(string, int);

	bool operator<=(IpCant pc2) {
		if (cantidad == pc2.cantidad)
			return true;
		else
		{
			if (cantidad < pc2.cantidad)
				return true;
			else
				return false;
		}
	}

	bool operator<(IpCant pc2) {
		if (cantidad < pc2.cantidad)
			return true;
		else
			return false;
	}

	bool operator==(IpCant pc2) {
		if (cantidad == pc2.cantidad)
			return true;
		else
			return false;
	}

	bool operator>=(IpCant pc2) {
		if (cantidad == pc2.cantidad)
			return true;
		else
		{
			if (cantidad > pc2.cantidad)
				return true;
			else
				return false;
		}
	}

	bool operator>(IpCant pc2) {
		if (cantidad > pc2.cantidad)
			return true;
		else
			return false;
	}
};

IpCant::IpCant() {
	code = "";
	cantidad = 0;
}
IpCant::IpCant(string code, int cantidad) {
	this->code = code;
	this->cantidad = cantidad;
}