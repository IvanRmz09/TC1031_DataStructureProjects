#include <iostream>
#include <string>
#include <ostream>
#include <fstream>
#include <sstream>
using namespace std;
#include "Heap.h"
#include "DoublyLinkedList.h"

template<class T>
void HeapSort(DoublyLinkedList<T>& list, string order = "ascending") {
	if (!list.isEmpty()) {
		Heap<T> heapAux(list);
		list.clear();
		while (!heapAux.isEmpty()) {
			T aux = heapAux.remove();
			if (order == "ascending") {
				list.addFirst(aux);
			}
			else {
				list.addLast(aux);
			}
		}
	}
}

template<class T>
void leerArchivo(DoublyLinkedList<T>& list) {
	string ip;
	string line = "", value = ""; // variables para leer archivo
	char delim = ' '; // caracter delimitador
	ifstream archivo("bitacora2.txt"); //Apertura del archivo
	while (getline(archivo, line)) { //Lectura de todo el archivo
		stringstream ss(line);
		int col = 0;
		while (getline(ss, value, delim)) { //lectura de todo el renglon separado por el caracter ' '
			if (col == 3) { // Para identificar que es lo que se está leyendo
				ip = value;
			}
			col++;
		}
		ip = ip.erase(ip.length() - 5); //Se crea el objeto y se añade a la DoublyList
		Ip ipObj(ip);
		list.addLast(ipObj);
	}
	archivo.close();
}



int main()
{
	DoublyLinkedList<Ip> listIp;
	DoublyLinkedList<IpCant> listIpC;
	leerArchivo(listIp);
	HeapSort(listIp);
	Ip ip = listIp[1];
	int cont = 1;
	for (int i = 2; i <= listIp.getSize(); i++) {
		if (listIp[i] == ip) {
			cont++;
		}
		else {
			IpCant ipc(listIp[i].code, cont);
			listIpC.addLast(ipc);	
			ip = listIp[i];
			cont = 1;
		}
	}

	Heap<IpCant> heapIpC(listIpC);
	for (int i = 1; i <= 5; i++) {
		cout <<i<<". "<< heapIpC.remove().code << endl;
	}

	return 0;
}

//Comentario: No funciona la sobrecarga del operador [] , excepcion ++: std::out_of_range. No pude encontrar forma de mantener
//la funcionalidad de los otros metodos sin eliminar dicha sobrecarga.