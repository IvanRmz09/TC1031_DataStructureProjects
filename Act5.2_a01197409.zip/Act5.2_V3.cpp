#include <iostream>
#include <string>
#include <ostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
#include "GraphL.h"

void leerArchivo(vector<vector<string>>& registros, vector<string>& vertices) {
    string ipSource = "";
    string ipTarget = "";
    int ips = 0, n = 0, l = 0;
    string line = "", value = ""; // variables para leer archivo
    char delim = ' '; // caracter delimitador
    ifstream archivo("bitacoraACT4_3.txt"); //Apertura del archivo
    getline(archivo, line); // lee la primera linea
    stringstream ss(line);
    while (getline(ss, value, delim)) {
        if (n == 0) {
            ips = stoi(value);
            n++;
        }
        else {
            int r = stoi(value);
            vector<vector<string>> tempRegistro(r);
            registros = tempRegistro;
        }
    }
    while (getline(archivo, line)) { //Lectura de todo el archivo
        if (ips <= 0) { //Para leer la lista de vertices
            stringstream ss(line);
            int col = 0;
            while (getline(ss, value, delim)) { //lectura de todo el renglon separado por el caracter ' '
                if (col == 3) { // Para identificar que es lo que se está leyendo
                    ipSource = value;
                    ipSource = ipSource.erase(ipSource.length() - 5);
                    registros[l].push_back(ipSource);
                }
                else if (col == 4) {
                    ipTarget = value;
                    ipTarget = ipTarget.erase(ipTarget.length() - 5);
                    registros[l].push_back(ipTarget);
                }
                col++;
            }
            l++;
        }
        else {
            stringstream ss(line);
            int col = 0;
            while (getline(ss, value, delim)) {
                if (col == 0) {
                    vertices.push_back(value);
                }
            }
            ips--;
        }
    }
    archivo.close();
}

int main() {
    string str;
    int resp = 1;
    vector<vector<string>> registros;
    vector<string> vertices;
    leerArchivo(registros, vertices);
    GraphL<string> graph(registros, vertices);
    while (resp == 1) {
        cout << "Actividad 5.2 - Hash" << endl;
        cout << "Ingrese la Ip que desea conocer sus adyacentes: "; cin >> str;
        cout << endl;
        graph.findHsh(str);
        cout<<"Ips con adyacencia a la ip"<<endl;
        graph.Adjacents(str);
        cout << endl << endl;
        cout << "Desea seguir consultando?" << endl;
        cout << "1. Si" << endl;
        cout << "2. No" << endl;
        cin >> resp;
        if (resp < 1 || resp>2) {
            cout << "Respuesta Invalida intente de nuevo: " << endl;
            cin >> resp;
        }
    }
    return 0;
}