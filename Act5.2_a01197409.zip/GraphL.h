#pragma once
#include <stack>
#include <vector>
#include <functional>
#include <string>
#include <queue>
using namespace std;
#include "HashL.h"

template<class T>
struct Edge{
	T target;
	int weight;
};

template<class T>
class GraphL {
private:
	vector< vector< Edge<T> > > adjList;
	HashL hashTable;
	//int findVrtx(T vertex);
	int findHshIndx(string str);
public: 
	GraphL(vector<vector<T>> list, vector<T> IpList);
	//void popTop();
	void Adjacents(string str);
	void findHsh(string str);
	void print();
};

template<class T>
GraphL<T>::GraphL(vector< vector<T> > list, vector<T> IpList) {
	int src = 0;
	int tgt = 1;
	int wght = 2;

	hashTable.setSize(13381);
	for(auto h : IpList){
		hashTable.addStr(h);
	}

	vector< vector<Edge<T>> > tempList(hashTable.getSize());
	adjList = tempList; //Hasta aqui tiene solo la primera posicion de cada vector con su nodo origen

	// Agregar targets a la lista de adjacencias
	for (auto path : list) {
		int posSrc = findHshIndx(path[src]);
		Edge<T> edge;
		edge.target = path[tgt];
		adjList[posSrc].push_back(edge);
	}
}

template<class T>
int GraphL<T>::findHshIndx(string str) {
	return hashTable.findStr(str);
}

template<class T>
void GraphL<T>::Adjacents(string str){
	int pos = hashTable.findStr(str);
	cout<<str<<" -> ";
	for (auto edge : adjList[pos]) {
		cout << edge.target<<" ";
	}
	cout << endl;
}

template<class T>
void GraphL<T>::findHsh(string str){
    int pos = hashTable.findStr(str);
    if (pos==-1){
        cout<<"Elemento no encontrado"<<endl;
    }else{
        cout<<endl<<"La ip: "<<str<<" se encuentra en la Hash Table en la posicion: "<<pos<<endl<<endl;
    }
}

template<class T>
void GraphL<T>::print() {
	for (int v=0; v<hashTable.getSize(); v++) {
		cout<<hashTable.getItem(v)<<" -> ";
		for (auto edge : adjList[v]) {
			cout << edge.target<<" ";
		}
		cout << endl;
	}
}