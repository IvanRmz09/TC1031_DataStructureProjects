#pragma once
#include <iostream>
#include <vector>
#include <math.h>
using namespace std;


class HashL{
private:
    vector<string> table;
    vector<int> status; //0-vacio, 1-ocupado, 2-borrado
    int size;
    int qty;
    int hashing(string str);
    bool isFull();
    int quadProbe(int index, int cont);
public:
    HashL();
    HashL(vector<string> list);
    void addStr(string str);
    int findStr(string str);
    void print();
    int getSize();
    string getItem(int indx);
    void setSize(int size);
};

HashL::HashL(){
    size = 0;
    qty = 0;
}

void HashL::setSize(int size){
    this->size = size;
    vector<string> tempTable(size);
    table = tempTable;
    vector<int> tempStatus(size, 0);
    status = tempStatus;
}

int HashL::getSize(){
    return size;
}

HashL::HashL(vector<string> list){
    qty = 0;
    size = list.size();
    vector<string> tempTable(size);
    table = tempTable;
    vector<int> tempStatus(size, 0);
    status = tempStatus;
    for(auto str : list){
        addStr(str);
    }
}

void HashL::addStr(string str){
    if(!isFull()){
        int indx = hashing(str);
        if(status[indx] == 0 || status[indx] == 2){
            table[indx] = str;
            status[indx] = 1;
            qty++;
        }else{
            //Validar si ya existe
            int cont = 1;
            int newIndex = quadProbe(indx,cont); // Cálculo del nuevo índice
            while (status[newIndex] == 1) { // Esta ocupado
                if (str == table[newIndex]) { // Validar si ya existe
                    throw runtime_error("El valor ya existe en la tabla");
                }
                cont++;
                newIndex = quadProbe(indx,cont);
            }
            table[newIndex] = str;
            status[newIndex] = 1; // Ocupadp
            qty++;
            return;
        }
    }else{
        cout<<"La tabla ya esta llena"<<endl;
    }
}

int HashL::findStr(string str){
    int cont = 1;
    int index = hashing(str);    
    while (status[index] != 0) {
        if (status[index] == 1 && table[index] == str) {
            return index;
        }
        cont++;
        index = quadProbe(index,cont);
    }
    return -1;
}

int HashL::quadProbe(int index, int cont) {
    int newIndex;
    if (index + int(pow(-1, cont - 1)) * int(pow((cont + 1) / 2, 2)) < 0) {
        newIndex = size - fmod(size - int(pow(-1, cont - 1)) * int(pow((cont + 1) / 2, 2)), size);
    } else {
        newIndex = fmod(index + int(pow(-1, cont - 1)) * int(pow((cont + 1) / 2, 2)), size);
    }
    return newIndex;
}

int HashL::hashing(string str){
    int indx, indx1, indx2, key;
    indx = str.find(".");
    indx1 = str.find(".", indx + 1);
    indx2 = str.find(".", indx1 + 1);

    string part1 = str.substr(indx1 + 1, indx2 - indx1 - 1);

    string part2 = str.substr(indx2 + 1, str.length() - indx2);

    key = stoi(part1) + stoi(part2);
    return key % size;
}

bool HashL::isFull(){
    if(size == 0){
        return false;
    }else{
        return size == qty;
    }
}

void HashL::print(){
    for(auto str : table){
        cout<<str<<endl;
    }
}

string HashL::getItem(int indx){
    return table[indx];
}