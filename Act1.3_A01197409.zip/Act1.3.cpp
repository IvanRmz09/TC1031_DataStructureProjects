#include <iostream>
#include <string>
#include <vector>
#include <ostream>
#include <fstream>
#include <sstream>

#include "Bitacora.h"

using namespace std;

//Arreglo del vector con los registros con el metodo de ordenamiento Bubble
void bubbleSort(vector<Bitacora*>& bitacora) {
	for (int i = bitacora.size() - 1; i > 0; i--) {
		for (int j = 0; j < i; j++) {
			if (bitacora[j]->getTiempo() > bitacora[j + 1]->getTiempo()) {
				swap(bitacora[j], bitacora[j + 1]);
			}
		}
	}
}


//funcion para leer el archivo bitacora.txt
void leerArchivo(vector<Bitacora*>& bitacora) {
	string mes = "", hora = "", ip, mensaje = "", parteMsj1 = "", parteMsj2 = "", parteMsj3 = "", parteMsj4 = "", parteMsj5 = "", parteMsj6 = "";
	string line = "", value = ""; // variables para leer archivo
	int dia = 0, tiempo = 0;
	char delim = ' '; // caracter delimitador
	ifstream archivo("bitacora.txt"); //Apertura del archivo
	while (getline(archivo, line)) { //Lectura de todo el archivo
		stringstream ss(line);
		int col = 0;
		while (getline(ss, value, delim)) { //lectura de todo el renglon separado por el caracter ' '
			switch (col) { // Para identificar que es lo que se está leyendo
			case 0:
				mes = value;
				break;
			case 1:
				dia = stoi(value);
				break;
			case 2:
				hora = value;
				break;
			case 3:
				ip = value;
				break;
			case 4:
				parteMsj1 = value;
				break;
			case 5:
				parteMsj2 = value;
				break;
			case 6:
				parteMsj3 = value;
				break;
			case 7:
				parteMsj4 = value;
				break;
			case 8:
				parteMsj5 = value;
				break;
			case 9:
				parteMsj6 = value;
				break;
			}
			col++;
		}
		mensaje = parteMsj1 + " " + parteMsj2 + " " + parteMsj3 + " " + parteMsj4 + " " + parteMsj5 + " " + parteMsj6;
		bitacora.push_back(new Bitacora(mes, dia, hora, ip, mensaje)); //Se crea el objeto y se añade al vector
	}
	archivo.close();
}

//Funcion para crear o sobrescribir sobre el archivo BitacoraArreglada.txt el nuevo vector de forma ordenada
void escribirArchivo(vector<Bitacora*> bitacora) {
	ofstream fileOut("BitacoraArreglada.txt");
	if (fileOut.is_open()) {
		for (int i = 0; i < bitacora.size(); i++) {
			fileOut << bitacora[i]->getMes() << " " << bitacora[i]->getDia() << " " << bitacora[i]->getHora() << " " << bitacora[i]->getIp() << " " << bitacora[i]->getMensaje();
			fileOut << endl;
		}
		fileOut.close();
		cout << "La base de registros fallados se ha ordenado, consultar en el archivo BitacoraArreglada.txt en la carpeta." << endl;
		cout << endl;
	}
	else {
		cout << "No se pudo abrir o  crear el archivo de texto" << endl;
	}
}

//Busqueda binaria para encontrar el indice del registro minimo que cumpla las condiciones
int binarySearchBot(vector<Bitacora*>& bitacora, int timeBot) {
	int mid, bot = 0, top = bitacora.size() - 1;
	while (bot < top) {
		mid = (bot + top) / 2;

		if (bitacora[mid]->getTiempo() >= timeBot) {
			if (bitacora[mid - 1]->getTiempo() < timeBot) {
				return mid;
			}
			else {
				top = mid - 1;
			}
		}
		else {
			bot = mid + 1;
		}
	}
	return bot;
}

//Busqueda binaria para encotrar el indice superior del registro maximo que cumpla las condiciones
int binarySearchTop(vector<Bitacora*>& bitacora, int timeTop) {
	int mid, bot = 0, top = bitacora.size() - 1;
	while (bot < top) {
		mid = (bot + top) / 2;

		if (bitacora[mid]->getTiempo() <= timeTop) {
			if (bitacora[mid + 1]->getTiempo() > timeTop) {
				return mid;
			}
			else {
				bot = mid + 1;
			}
		}
		else {
			top = mid - 1;
		}
	}
	return bot;
}

//Metodo para calcular la fecha y hora de forma entera para hacer comparaciones
int calcularTiempo(string mes, int dia, string hora) {
	int mesInt = 0, horaInt = 0;
	string horaAux = hora;
	horaAux.erase(remove(horaAux.begin(), horaAux.end(), ':'), horaAux.end());
	horaInt = stoi(horaAux);
	if (mes == "Jun") {
		mesInt = 600000000;
	}
	else if (mes == "Jul") {
		mesInt = 700000000;
	}
	else if (mes == "Aug") {
		mesInt = 800000000;
	}
	else if (mes == "Sep") {
		mesInt = 900000000;
	}
	else if (mes == "Oct") {
		mesInt = 1000000000;
	}
	else {
		return -1;
	}
	int diaAux = dia * 1000000;
	return mesInt + diaAux + horaInt;
}

int main()
{
	vector<Bitacora*> bitacora; //vector de toda la bitacora
	int indx = 0;
	string mesBot, mesTop, horaBot, horaTop;
	int diaBot, diaTop, timeBot, timeTop, ans = 0, indxBot, indxTop;
	leerArchivo(bitacora); //lee el archivo y llena el vector de los registros
	cout << "Inicio del programa de la Actividad 1.3" << endl;
	bubbleSort(bitacora); //arregla el archivo de forma cronologica
	escribirArchivo(bitacora); //escribe el vector sobre un archivo .txt
	do {
		cout << "Desea seguir consultando registros?" << endl;
		cout << "1. Si" << endl;
		cout << "2. No" << endl;
		cin >> ans;
	} while (ans < 1 || ans>2);
	while (ans == 1) {
		cout << "------Consulta de registros por Fecha y Hora------" << endl;
		cout << "Fecha y hora del parametro inferior" << endl;
		cout << "Ingresa las primeras 3 letras del mes: "; cin >> mesBot;
		cout << "Ingresa el dia que buscas: "; cin >> diaBot;
		while (diaBot > 31) {
			cout << "El numero de dia no valido, ingrese otro valor: "; cin >> diaBot;
		}
		cout << "Ingresa la hora que buscas en formato hh:mm:ss: "; cin >> horaBot;
		while (horaBot[2] != ':' || horaBot[5] != ':') {
			cout << "El formato en el que se ingreso la hora no es valido, intente de nuevo como hh:mm:ss: "; cin >> horaBot;
		}
		timeBot = calcularTiempo(mesBot, diaBot, horaBot); //calcula la fecha y hora de forma entera del paramtero inferior
		cout << endl;
		cout << "Fecha y hora del parametro superior" << endl;
		cout << "Ingresa las primeras 3 letras del mes: "; cin >> mesTop;
		cout << "Ingresa el dia que buscas: "; cin >> diaTop;
		while (diaTop > 31) {
			cout << "El numero de dia no valido, ingrese otro valor: "; cin >> diaTop;
		}
		cout << "Ingresa la hora que buscas en formato hh:mm:ss: "; cin >> horaTop;
		while (horaTop[2] != ':' || horaTop[5] != ':') {
			cout << "El formato en el que se ingreso la hora no es valido, intente de nuevo como hh:mm:ss: "; cin >> horaTop;
		}
		timeTop = calcularTiempo(mesTop, diaTop, horaTop); //calcula la fecha y hora de forma entera del paramtero superior
		cout << endl;
		cout << endl;
		cout << "Resultados: " << endl;
		cout << "Indice inferior de busqueda: Mes->" << mesBot << " Dia-> " << diaBot << " Hora->" << horaBot << endl;
		cout << "Indice superior de busqueda: Mes->" << mesTop << " Dia-> " << diaTop << " Hora->" << horaTop << endl;
		if (timeBot >= 0 && timeTop >= 0) { //Si un valor es menor a 1 quiere decir que no se encontro en la lista de registros
			indxBot = binarySearchBot(bitacora, timeBot); //encontrar el indice del minimo elemento que cumpla la condicion
			indxTop = binarySearchTop(bitacora, timeTop); //encontrar el indice del maximo elemento que cumpla la condicion
			for (int i = indxBot; i <= indxTop; i++) {
				bitacora[i]->imprimirRegistro();
			}
			cout << endl;
			cout << endl;
		}
		else {
			cout << "La Busqueda que solicito es invalida" << endl;
			cout << endl;
			cout << endl;
		}
		do {
			ans = 0;
			cout << "Desea seguir consultando registros?" << endl;
			cout << "1. Si" << endl;
			cout << "2. No" << endl;
			cin >> ans;
		} while (ans < 1 || ans>2);
		cout << endl;
		cout << endl;
	}
	cout << "Fin del programa . . . " << endl;
	return 0;
}

//Por: Iván Enrique Ramírez Martínez    A01197409