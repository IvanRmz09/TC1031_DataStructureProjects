#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>

using namespace std;

struct Bitacora {
	string mes;
	int dia;
	string hora;
	string ip;
	string mensaje;
	int tiempo;

	Bitacora();
	Bitacora(string, int, string, string, string);
	void setMes(string);
	void setDia(int);
	void setHora(string);
	void setIp(string);
	void setMensaje(string);
	void setTiempo(int);
	string getMes();
	int getDia();
	string getHora();
	string getIp();
	string getMensaje();
	int getTiempo();
	int calcularTiempo();
	void imprimirRegistro();
};

Bitacora::Bitacora() {
	mes = "";
	dia = 0;
	hora = "";
	ip = "";
	mensaje = "";
	tiempo = 0;
}

Bitacora::Bitacora(string mes, int dia, string hora, string ip, string mensaje) {
	this->mes = mes;
	this->dia = dia;
	this->hora = hora;
	this->ip = ip;
	this->mensaje = mensaje;
	this->tiempo = calcularTiempo();
}

void Bitacora::setMes(string mes) {
	this->mes = mes;
}

void Bitacora::setDia(int dia) {
	this->dia = dia;
}

void Bitacora::setHora(string hora) {
	this->hora = hora;
}

void Bitacora::setIp(string ip) {
	this->ip = ip;
}

void Bitacora::setMensaje(string mensaje) {
	this->mensaje = mensaje;
}

void Bitacora::setTiempo(int tiempo) {
	this->tiempo = tiempo;
}

string Bitacora::getMes() {
	return mes;
}

int Bitacora::getDia() {
	return dia;
}

string Bitacora::getHora() {
	return hora;
}

string Bitacora::getIp() {
	return ip;
}

string Bitacora::getMensaje() {
	return mensaje;
}

int Bitacora::getTiempo() {
	return tiempo;
}

int Bitacora::calcularTiempo() {
	int mesInt = 0;
	int horaInt;
	string horaAux = hora;
	horaAux.erase(remove(horaAux.begin(), horaAux.end(), ':'), horaAux.end());
	horaInt = stoi(horaAux);
	if (mes == "Jun") {
		mesInt = 600000000;
	}
	else if (mes == "Jul") {
		mesInt = 700000000;
	}
	else if (mes == "Aug") {
		mesInt = 800000000;
	}
	else if (mes == "Sep") {
		mesInt = 900000000;
	}
	else if (mes == "Oct") {
		mesInt = 1000000000;
	}
	int diaAux = dia * 1000000;

	return mesInt + diaAux + horaInt;
}

void Bitacora::imprimirRegistro() {
	cout << mes << " " << dia << " " << hora << " " << ip << " " << mensaje << endl;
}