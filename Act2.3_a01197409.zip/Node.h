#pragma once

#include "Bitacora.h"

struct Node {
	Bitacora bitacora; //Informaci�n que almacena
	Node* next;			//Direccion de memoria del siguiente nodo
	Node* prev;			//Direccion de memoria del nodo previo
	Node(Bitacora bitacora);
	Node(Bitacora bitacora, Node* next, Node* prev);
};

Node::Node(Bitacora bitacora) {
	this->bitacora = bitacora;
	next = NULL;
	prev = NULL;
}

Node::Node(Bitacora bitacora, Node* next, Node* prev) {
	this->bitacora = bitacora;
	this->next = next;
	this->prev = prev;
}