#pragma once

#include "NodeQ.h"
using namespace std;

class Queue {
private:
	NodeQ* head;
	NodeQ* tail;
	int size;
public:
	Queue();
	void enQueue(NodeQ*);
	bool isEmpty();
	int getSize();
	Bitacora deQueue();
	Bitacora peekHead();
	Bitacora peekTail();
	void print(int, int);
};

Queue::Queue() {
	head = NULL;
	tail = NULL;
	size = NULL;
}

void Queue::enQueue(NodeQ* node) {
	if (!isEmpty()) {
		NodeQ* aux = head;
		while (aux->next != NULL) {
			aux = aux->next;
		}
		aux->next = node;
		tail = aux->next;
		size++;
	}
	else {
		head = node;
		tail = head;
		size++;
	}
}

bool Queue::isEmpty() {
	return size == 0;
}

Bitacora Queue::deQueue() {
	Bitacora registro;
	if (!isEmpty()) {
		registro = head->bitacora;
		NodeQ* temp = head;
		head = head->next;
		delete temp;
		size--;
		return registro;
	}
	else {
		throw runtime_error("El queue esta vacio");
	}
}

Bitacora Queue::peekHead() {
	if (!isEmpty()) {
		return head->bitacora;
	}
	else {
		throw runtime_error("El queue esta vacio");
	}
}

Bitacora Queue::peekTail() {
	if (!isEmpty()) {
		return tail->bitacora;
	}
	else {
		throw runtime_error("El queue esta vacio");
	}
}

int Queue::getSize() {
	return size;
}

void Queue::print(int indexBot, int indexTop) {
	NodeQ* aux = head;
	int cont = 0;
	while (aux->next != NULL) {
		if (cont == indexBot) {
			for (int i = indexBot; i <= indexTop; i++) {
				aux->bitacora.imprimirRegistro();
				aux = aux->next;
			}
			return;
		}
		else {
			aux = aux->next;
			cont++;
		}
	}
}