#pragma once

#include "Bitacora.h"

using namespace std;

struct NodeQ {
	Bitacora bitacora;
	NodeQ* next;
	NodeQ(Bitacora);
	NodeQ(Bitacora, NodeQ*);
};


NodeQ::NodeQ(Bitacora bitacora) {
	this->bitacora = bitacora;
	this->next = NULL;
}

NodeQ::NodeQ(Bitacora bitacora, NodeQ* next) {
	this->bitacora = bitacora;
	this->next = next;
}