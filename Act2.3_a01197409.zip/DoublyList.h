#pragma once

#include "Node.h"
#include "Bitacora.h"
#include "Queue.h"

using namespace std;

class DoublyList {
private:
	Node* head;
	Node* tail;
	int size;
public:
	DoublyList();
	bool isEmpty();
	void addLast(Node* n);
	int getSize();
	Node* getHead();
	void getBitacora(int, int);  //funciona como el print
	Node* getToMid(int mid);
	Bitacora getData(int);
	void updateAt(int, Bitacora);
	int findDataBot(int);
	int findDataTop(int);
	void escribirArchivo();
	void Merge(int, int, int);
	void mergeSort(int, int);
	void emergencyBubbleSort();
};

DoublyList::DoublyList() {
	head = NULL;
	tail = NULL;
	size = 0;
}

void DoublyList::addLast(Node* n) {
	if (!isEmpty()) {
		Node* last = head;
		while (last->next != NULL) {
			last = last->next;
		}
		last->next = n;
		n->prev = last;
	}
	else {
		head = n;
		tail = head;
	}
	size++;
}

bool DoublyList::isEmpty() {
	return size == 0;
}

int DoublyList::getSize() {
	return size;
}

Node* DoublyList::getToMid(int mid) {
	Node* aux = head;
	for (int i = 0; i < mid; i++) {
		aux = aux->next;
	}
	return aux;
}

int DoublyList::findDataBot(int timeBot) {  //Busqueda Binaria para encontrar el parametro inferior
	int mid, bot = 0, top = size - 1;
	Node* aux = head;
	while (bot < top) {
		mid = (bot + top) / 2;
		aux = getToMid(mid);
		if (aux->bitacora.tiempo >= timeBot) {
			if (aux->prev->bitacora.tiempo < timeBot) {
				return mid;
			}
			else {
				top = mid - 1;
			}
		}
		else {
			bot = mid + 1;
		}
	}
	return bot;
}

int DoublyList::findDataTop(int timeBot) {  //Busqueda Binaria para encontrar el parametro superior
	int mid, bot = 0, top = size - 1;
	Node* aux = head;
	while (bot < top) {
		mid = (bot + top) / 2;
		aux = getToMid(mid);
		if (aux->bitacora.tiempo >= timeBot) {
			if (aux->next->bitacora.tiempo < timeBot) {
				return mid;
			}
			else {
				top = mid - 1;
			}
		}
		else {
			bot = mid + 1;
		}
	}
	return bot;
}

void DoublyList::getBitacora(int indexBot, int indexTop) {
	Node* aux = head;
	int cont = 0;
	while (aux->next != NULL) {
		if (cont == indexBot) {
			for (int i = indexBot; i <= indexTop; i++) {
				aux->bitacora.imprimirRegistro();
				aux = aux->next;
			}
			return;
		}
		else {
			aux = aux->next;
			cont++;
		}
	}
}

Node* DoublyList::getHead() {
	return head;
}

void DoublyList::escribirArchivo() {
	if (head == NULL) {
		cout << "La lista est� vacia" << endl;
	}
	else {
		remove("BitacoraArreglada.txt");
		ofstream f("BitacoraArreglada.txt");
		if (f.is_open()) {
			Node* aux = head;
			while (aux != NULL) {
				f << aux->bitacora.mes << "      " << aux->bitacora.dia << "     " << aux->bitacora.hora << "          " << aux->bitacora.ip << "    " << aux->bitacora.mensaje << endl;
				aux = aux->next;
			}
			cout << endl;
			cout << "\n La bitacora fue escrita en el archivo BitacoraArreglada.txt, para encontrarlo buscar en la carpeta del proyecto\n" << endl;
		}
		else cout << "Error, el archivo no se pudo crear" << endl;
	}
}

void DoublyList::updateAt(int index, Bitacora bitacora) {
	if (index >= size || isEmpty()) {
		throw out_of_range("No se puede realizar proceso");
	}
	else {
		if (index == 0) {
			head->bitacora = bitacora;
		}
		else {
			Node* aux = head;
			Node* prev = aux;
			for (int i = 0; i < index; i++) {
				aux = aux->next;
				prev = aux;
			}
			aux->bitacora = bitacora;
			aux->prev = prev;
		}
	}
}

Bitacora DoublyList::getData(int index) {
	if (isEmpty() || index >= size) {
		throw runtime_error("No se pudo realizar el getData DoublyList");
	}
	else {
		if (index == 0) {
			return head->bitacora;
		}
		else {
			Node* aux = head;
			for (int i = 0; i < index; i++) {
				aux = aux->next;
			}
			return aux->bitacora;
		}
	}
}

void DoublyList::Merge(int bot, int mid, int top) {
	Queue queueL;
	Queue queueR;

	int pos, f1, f2, i, j;
	pos = bot;
	f1 = mid - bot + 1;
	f2 = top - mid;
	for (i = 0; i < f1; i++) {
		NodeQ* node = new NodeQ(getData(bot + i));
		queueL.enQueue(node);
	}
	for (j = 0; j < f2; j++) {
		NodeQ* node = new NodeQ(getData(mid + 1 + j));
		queueR.enQueue(node);
	}
	i = 0;
	j = 0;
	while (i < f1 && j < f2) {
		if (queueL.peekHead().tiempo <= queueR.peekHead().tiempo) {
			updateAt(pos, queueL.deQueue());
			i++;
		}
		else {
			updateAt(pos, queueR.deQueue());
			j++;
		}
		pos++;
	}
	while (i < f1) {
		updateAt(pos, queueL.deQueue());
		i++;
		pos++;
	}
	while (j < f2) {
		updateAt(pos, queueR.deQueue());
		j++;
		pos++;
	}
}

//MERGE SORT
void DoublyList::mergeSort(int bot, int top) {
	if (!isEmpty()) {
		if (bot < top) {
			int mid = (bot + top) / 2;
			mergeSort(bot, mid);
			mergeSort(mid + 1, top);
			Merge(bot, mid, top);
		}
	}
	else {
		throw runtime_error("la lista esta vacia");
	}
}

void DoublyList::emergencyBubbleSort() {
	for (int i = getSize() - 1; i > 0; i--) {
		for (int j = 0; j < i; j++) {
			if (getData(j).tiempo > getData(j + 1).tiempo) {
				Bitacora regAux = getData(j);
				Bitacora regAux2 = getData(j + 1);

				updateAt(j, regAux2);
				updateAt(j + 1, regAux);
			}
		}
	}
}