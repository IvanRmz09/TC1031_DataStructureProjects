#include <iostream>
#include <string>
#include <vector>
#include <ostream>
#include <fstream>
#include <sstream>

#include "Bitacora.h"
#include "DoublyList.h"
#include "Node.h"
#include "NodeQ.h"
#include "Queue.h"

using namespace std;

//funcion para leer el archivo bitacora.txt
void leerArchivo(DoublyList& list) {
	string mes = "", hora = "", ip, mensaje = "", parteMsj1 = "", parteMsj2 = "", parteMsj3 = "", parteMsj4 = "", parteMsj5 = "", parteMsj6 = "";
	string line = "", value = ""; // variables para leer archivo
	int dia = 0, tiempo = 0;
	char delim = ' '; // caracter delimitador
	ifstream archivo("bitacora.txt"); //Apertura del archivo
	while (getline(archivo, line)) { //Lectura de todo el archivo
		stringstream ss(line);
		int col = 0;
		while (getline(ss, value, delim)) { //lectura de todo el renglon separado por el caracter ' '
			switch (col) { // Para identificar que es lo que se est� leyendo
			case 0:
				mes = value;
				break;
			case 1:
				dia = stoi(value);
				break;
			case 2:
				hora = value;
				break;
			case 3:
				ip = value;
				break;
			case 4:
				parteMsj1 = value;
				break;
			case 5:
				parteMsj2 = value;
				break;
			case 6:
				parteMsj3 = value;
				break;
			case 7:
				parteMsj4 = value;
				break;
			case 8:
				parteMsj5 = value;
				break;
			case 9:
				parteMsj6 = value;
				break;
			}
			col++;
		}
		mensaje = parteMsj1 + " " + parteMsj2 + " " + parteMsj3 + " " + parteMsj4 + " " + parteMsj5 + " " + parteMsj6;
		Node* n = new Node(Bitacora(mes, dia, hora, ip, mensaje)); //Se crea el objeto y se a�ade a la DoublyList
		list.addLast(n);
	}
	archivo.close();
}

//Metodo para calcular la fecha y hora de forma entera para hacer comparaciones
int calcularTiempo(string mes, int dia, string hora) {
	int mesInt = 0, horaInt = 0;
	string horaAux = hora;
	horaAux.erase(remove(horaAux.begin(), horaAux.end(), ':'), horaAux.end());
	horaInt = stoi(horaAux);
	if (mes == "Jun") {
		mesInt = 600000000;
	}
	else if (mes == "Jul") {
		mesInt = 700000000;
	}
	else if (mes == "Aug") {
		mesInt = 800000000;
	}
	else if (mes == "Sep") {
		mesInt = 900000000;
	}
	else if (mes == "Oct") {
		mesInt = 1000000000;
	}
	else {
		return -1;
	}
	int diaAux = dia * 1000000;
	return mesInt + diaAux + horaInt;
}

int main()
{
	DoublyList list; //Doubly List con todos los nodo (registros)
	leerArchivo(list); //lee el archivo y llena el Doubly de los registros
	string mesBot, mesTop, horaBot, horaTop;
	int diaBot, diaTop, timeBot, timeTop, ans = 0, indxBot, indxTop, listSize = 0;
	cout << "Inicio del programa de la Actividad 2.3" << endl;
	listSize = list.getSize() - 1;
	cout << endl;
	list.mergeSort(0, listSize);
	list.escribirArchivo();
	do {
		cout << "Desea seguir consultando registros?" << endl;
		cout << "1. Si" << endl;
		cout << "2. No" << endl;
		cin >> ans;
	} while (ans < 1 || ans>2);
	while (ans == 1) {
		cout << "------Consulta de registros por Fecha y Hora------" << endl;
		cout << "Fecha y hora del parametro inferior" << endl;
		cout << "Ingresa las primeras 3 letras del mes: "; cin >> mesBot;
		cout << "Ingresa el dia que buscas: "; cin >> diaBot;
		while (diaBot > 31) {
			cout << "El numero de dia no valido, ingrese otro valor: "; cin >> diaBot;
		}
		cout << "Ingresa la hora que buscas en formato hh:mm:ss: "; cin >> horaBot;
		while (horaBot[2] != ':' || horaBot[5] != ':') {
			cout << "El formato en el que se ingreso la hora no es valido, intente de nuevo como hh:mm:ss: "; cin >> horaBot;
		}
		timeBot = calcularTiempo(mesBot, diaBot, horaBot); //calcula la fecha y hora de forma entera del paramtero inferior
		cout << endl;
		cout << "Fecha y hora del parametro superior" << endl;
		cout << "Ingresa las primeras 3 letras del mes: "; cin >> mesTop;
		cout << "Ingresa el dia que buscas: "; cin >> diaTop;
		while (diaTop > 31) {
			cout << "El numero de dia no valido, ingrese otro valor: "; cin >> diaTop;
		}
		cout << "Ingresa la hora que buscas en formato hh:mm:ss: "; cin >> horaTop;
		while (horaTop[2] != ':' || horaTop[5] != ':') {
			cout << "El formato en el que se ingreso la hora no es valido, intente de nuevo como hh:mm:ss: "; cin >> horaTop;
		}
		timeTop = calcularTiempo(mesTop, diaTop, horaTop); //calcula la fecha y hora de forma entera del paramtero superior
		cout << endl;
		cout << endl;
		cout << "Resultados: " << endl;
		cout << "Indice inferior de busqueda: Mes->" << mesBot << " Dia-> " << diaBot << " Hora->" << horaBot << endl;
		cout << "Indice superior de busqueda: Mes->" << mesTop << " Dia-> " << diaTop << " Hora->" << horaTop << endl;
		cout << timeBot << endl;
		cout << timeTop << endl;
		if (timeBot >= 0 && timeTop >= 0) { //Si un valor es menor a 1 quiere decir que no se encontro en la lista de registros
			indxBot = list.findDataBot(timeBot); //encontrar el indice del minimo elemento que cumpla la condicion
			indxTop = list.findDataTop(timeTop); //encontrar el indice del maximo elemento que cumpla la condicion
			cout << indxBot << " - " << indxTop << endl;
			list.getBitacora(indxBot, indxTop);
			cout << endl;
			cout << endl;
		}
		else {
			cout << "La Busqueda que solicito es invalida" << endl;
			cout << endl;
			cout << endl;
		}
		do {
			ans = 0;
			cout << "Desea seguir consultando registros?" << endl;
			cout << "1. Si" << endl;
			cout << "2. No" << endl;
			cin >> ans;
		} while (ans < 1 || ans>2);
		cout << endl;
		cout << endl;
	}
	cout << "Fin del programa . . . " << endl;
	return 0;
}

//Por: Iv�n Enrique Ram�rez Mart�nez    A01197409