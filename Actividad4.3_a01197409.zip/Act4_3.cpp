#include <iostream>
#include <string>
#include <ostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
#include "GraphL.h"


void leerArchivo(vector<vector<string>> &registros) {
    string ipSource = "";
    string ipTarget = "";
    int ips = 0, n = 0, l = 0;
    string line = "", value = ""; // variables para leer archivo
    char delim = ' '; // caracter delimitador
    ifstream archivo("bitacoraACT4_3.txt"); //Apertura del archivo
    getline(archivo, line); // lee la primera linea
    stringstream ss(line);
    while (getline(ss, value, delim)) {
        if (n == 0) {
            ips = stoi(value);
            n++;
        }
        else {
            int r = stoi(value);
            vector<vector<string>> tempRegistro(r);
            registros = tempRegistro;
        }
    }
    while (getline(archivo, line)) { //Lectura de todo el archivo
        if (ips <= 0) { //Para leer la lista de vertices
            stringstream ss(line);
            int col = 0;
            while (getline(ss, value, delim)) { //lectura de todo el renglon separado por el caracter ' '
                if (col == 3) { // Para identificar que es lo que se está leyendo
                    ipSource = value;
                    ipSource = ipSource.erase(ipSource.length() - 5);
                    registros[l].push_back(ipSource);
                }
                else if (col == 4) {
                    ipTarget = value;
                    ipTarget = ipTarget.erase(ipTarget.length() - 5);
                    registros[l].push_back(ipTarget);
                }
                col++;
            }
            l++;
        }
        ips--;
    }
    archivo.close();
}

int main(){
    int n;
    vector<vector<string>> registros;
    leerArchivo(registros);
    GraphL<string> graph(registros);
    cout<<"Actividad 4.3 - Grafos"<<endl;
    cout<<"Ingrese numero de Ips con mayor adyacencias que desee conocer: ";cin>>n;
    for(int i = 0; i<n; i++){
        graph.popTop();
    }
    return 0;
}