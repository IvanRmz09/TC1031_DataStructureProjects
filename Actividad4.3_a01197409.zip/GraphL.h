#pragma once
#include <stack>
#include <vector>
#include <functional>
#include <string>
#include <queue>
using namespace std;

template<class T>
struct Edge{
	T target;
	int weight;
};

class Ip{
public:
	string ip;
    int adj;

	Ip(string ip, int adj){
    this->ip = ip;
    this->adj = adj;
	}
};

bool operator<(const Ip& ip1, const Ip& ip2) 
{ 
    return ip1.adj < ip2.adj; 
} 

template<class T>
class GraphL {
private:
	vector< vector< Edge<T> > > adjList;
	priority_queue<Ip> ips;
	vector<T> vertices;
	int findVrtx(T vertex);
	void dfsR(T vertex, vector<bool> &status);
	int findMin(vector<int> &weight, vector<bool> &status);
public: 
	GraphL(vector<vector<T>> list);
	void breadthFirstSrch();
	void depthFirstSrch();
	void shortestPath(T vertex);
	void popTop();
	void print();
};

template<class T>
GraphL<T>::GraphL(vector< vector<T> > list) {
	int src = 0;
	int tgt = 1;
	int wght = 2;
	for (auto edge : list) {
		int pos = findVrtx(edge[src]);
		if (pos < 0) {
			vertices.push_back(edge[src]);
		}
		pos = findVrtx(edge[tgt]);
		if (pos < 0) {
			vertices.push_back(edge[tgt]);
		}
	}

	sort(vertices.begin(), vertices.end());

	vector< vector<Edge<T>> > tempList(vertices.size());
	adjList = tempList; //Hasta aqui tiene solo la primera posicion de cada vector con su nodo origen

	// Agregar targets a la lista de adjacencias
	//Este for va para la funcion addEdge
	for (auto path : list) {
		int posSrc = findVrtx(path[src]);
		Edge<T> edge;
		edge.target = path[tgt];
		//edge.weight = path[wght];
		adjList[posSrc].push_back(edge);
	}
}

template<class T>
int GraphL<T>::findVrtx(T vertex) {
	typename vector<T>::iterator it;
	it = find(vertices.begin(), vertices.end(), vertex);
	if (it != vertices.end()) {
		return it - vertices.begin();
	}
	else {
		return -1;
	}
}

template<class T>
void GraphL<T>::popTop(){
	for(int i = 0; i<vertices.size(); i++){ 
		Ip aux = Ip(vertices[i], adjList[i].size());
		ips.push(aux);
	}
	Ip temp = ips.top();
	ips.pop();
	cout<<"Ip: "<<temp.ip<<", Numero de Adyacencias: "<<temp.adj<<endl;
}

template<class T>
void GraphL<T>::breadthFirstSrch(){
	queue<int> q;
	vector<bool> status(adjList.size(), false);
	int vertex = 0;
	q.push(vertex);
	status[vertex] == true;
	while(!q.empty()){
		vertex = q.front();
		for(auto vrtx : adjList[vertex]){
			int pos = findVrtx(vrtx.target);
			if(!status[pos]){
				q.push(pos);
				status[pos] = true;
			}
		}
		q.pop();
		cout<<vertices[vertex]<<" ";
	}
	cout<<endl;
}

template<class T>
void GraphL<T>::depthFirstSrch(){
	vector<bool> status(vertices.size(), false);
	for(int v=0; vertices.size(); v++){
		if(!status[v]){
			dfsR(vertices[0], status);
		}
	}
	cout<<endl;
}



template<class T>
void GraphL<T>::dfsR(T vertex, vector<bool> &status){
	int pos = findVrtx(vertex);
	if(!status[pos]){
		cout<<vertex<<" ";
		status[pos] = true;
		for(auto adj : adjList[pos]){
			int posAdj = findVrtx(adj.target);
			if(!status[posAdj]){
				dfsR(adj.target, status);
			}
		}
	}
}

template<class T>
void GraphL<T>::shortestPath(T vertex){
	vector<bool> status(vertices.size(), false);
	vector<int> weight(vertices.size(), INT_MAX);
	vector<int> path(vertices.size(), -1);
	stack<int> sPaths;
	vector<stack<int>> paths(vertices.size(), sPaths);

	int pos = findVrtx(vertex);

	//Encuentra la forma más rápida de llegar a cada vertice
	if(pos >= 0){
		weight[pos] = 0;
		int minVrtx = findMin(weight, status);
		while(minVrtx >= 0){
			status[minVrtx] = true;
			for(auto adj : adjList[minVrtx]){
				int posAdj = findVrtx(adj.target);
				if(!status[posAdj]){
					if(weight[posAdj]>weight[minVrtx]+adj.weight){
						weight[posAdj] = weight[minVrtx]+adj.weight;
						path[posAdj] = minVrtx;
					}
				}
			}
			minVrtx = findMin(weight, status);
		}
	}

	//Halla el recorrido completo para llegar al Vertice
	for(int v=0; v<vertices.size(); v++){
		paths[v].push(v);
		int nextVertex = v;
		while(path[nextVertex] >= 0){
			paths[v].push(path[nextVertex]);
			nextVertex = path[nextVertex];
		}
	}

	//Imprimir los Paths
	for(int v=0; v<vertices.size(); v++){
		cout<<"Path of "<< v << ": ";
		while (!paths[v].empty()){
			cout<<paths[v].top()<<" ";
			paths[v].pop();
		}
		cout<< "\t  Weight: "<< weight[v] <<endl;
	}
}

template<class T>
int GraphL<T>::findMin(vector<int> &weight, vector<bool> &status){
	int min = INT_MAX;
	int minVrtx = -1;
	for(int v = 0; v<vertices.size(); v++){
		if(!status[v]){
			if(weight[v] < min){
				min = weight[v];
				minVrtx = v;
			}
		}
	}
	return minVrtx;
}

template<class T>
void GraphL<T>::print() {
	for (int v=0; v<vertices.size(); v++) {
		cout<<vertices[v]<<" -> ";
		for (auto edge : adjList[v]) {
			cout << edge.target<<" ";
		}
		cout << endl;
	}
}